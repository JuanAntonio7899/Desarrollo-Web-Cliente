window.onload = function () {

    //Apartado A

    let BotonA = document.getElementsByTagName("input")[0];

    const url = "https://randomuser.me/api";

    BotonA.addEventListener("click", function () {

        fetch(url)
            .then(function (respuesta) {
                if (!respuesta.ok) {
                    throw new Error("Error al cargar el usuario: " + respuesta.status);
                }
                return respuesta.json();
            })
            .then(function (datos) {
                datos.results.forEach(usuario => {

                    console.log(usuario);


                });


            })


    })


    //Apartado B

    let BotonB = document.getElementsByTagName("input")[1];

    BotonB.addEventListener("click", function () {

        fetch(url)
            .then(function (respuesta) {
                if (!respuesta.ok) {
                    throw new Error("Error al cargar el usuario: " + respuesta.status);
                }
                return respuesta.json();
            })
            .then(function (datos) {
                datos.results.forEach(usuario => {

                    let div = document.getElementsByTagName("div")[0];


                    //Creamos el article
                    let article = document.createElement("article");
                    //Le ponemos la clase usuario
                    article.setAttribute("class", "usuario");

                    div.appendChild(article);


                    let nombre = document.createElement("p");
                    let apellido = document.createElement("p");
                    let edad = document.createElement("p");
                    let imagen = document.createElement("img");



                    nombre.appendChild(document.createTextNode("Nombre: " + usuario.name.first));
                    apellido.appendChild(document.createTextNode("Apellido: " + usuario.name.last));
                    edad.appendChild(document.createTextNode("Edad: " + usuario.dob.age));
                    imagen.src = usuario.picture.medium;

                    article.appendChild(nombre);
                    article.appendChild(apellido);
                    article.appendChild(edad);
                    article.appendChild(imagen);






                });


            })


    })




}