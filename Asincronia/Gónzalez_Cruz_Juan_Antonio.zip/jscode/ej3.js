window.onload = function () {
    event.preventDefault();
    
   
    let div = document.getElementById("salida");


    //Apartado A
    let url = "http://www.jaimeweb.es/medac/getProfesores.php";

    let obtener = document.getElementsByTagName("input")[0];

    obtener.addEventListener("click", function () {

        fetch(url)
            .then(function (respuesta) {
                if (!respuesta.ok) {
                    throw new Error("Error al cargar el usuario: " + respuesta.status);
                }
                return respuesta.json();
            })
            .then(function (datos) {
                datos.forEach(usuario => {

                    console.log(usuario);

                    //Apartado B





                    let nombre = document.createElement("p");
                    let dni = document.createElement("p");



                    nombre.setAttribute("class", "ficha");
                    dni.setAttribute("class", "ficha");

                    nombre.appendChild(document.createTextNode(usuario.nombre));
                    dni.appendChild(document.createTextNode(dni.nombre));

                    div.appendChild(nombre);
                    div.appendChild(dni);


                });


            })


    })

    //Apartado C

    // let nombre = document.getElementsByTagName("input")[1].value;
    // let dni = document.getElementsByTagName("input")[2].value;
    // let edad = document.getElementsByTagName("input")[3].value;
    let enviar = document.getElementsByTagName("input")[4];

    let formu = document.getElementsByTagName("form")[1];
    let fd = new FormData(formu);

    let url2 = "http://www.jaimeweb.es/medac/setProfesores.php"

    const cabecera = {
        method: "POST",
        body: fd
    }

    console.log(fd);
   







    enviar.addEventListener("click", function () {
        

        fetch(url2, cabecera)
            .then(function (respuesta) {

                if (!respuesta.ok) {
                    throw new Error("Error del fetch: " + error);
                };

                return respuesta.json();
            })
            .then(function () {

                let nombre = document.createElement("p");
                let dni = document.createElement("p");
                let edad = document.createElement("p");



                nombre.setAttribute("class", "ficha");
                dni.setAttribute("class", "ficha");
                edad.setAttribute("class", "ficha");



                nombre.appendChild(document.createTextNode(usuario.nombre));
                dni.appendChild(document.createTextNode(dni.nombre));
                edad.appendChild(document.createTextNode(edad.nombre));

                div.appendChild(nombre);
                div.appendChild(dni);
                div.appendChild(edad);





            })
            .catch(function (error) {
                alert("Problemas accediendo a la URL: " + error);
            })


    })





}