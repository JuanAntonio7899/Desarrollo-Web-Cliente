window.onload = function () {

    //Apartado A y B
    let boton = document.getElementsByTagName("input")[0];

    let url = "http://www.jaimeweb.es/medac/datos.json"


    boton.addEventListener("click", function () {

        fetch(url)
            .then(function (respuesta) {
                if (!respuesta.ok) {
                    throw new Error("Error al cargar el usuario: " + respuesta.status);
                }
                return respuesta.json();
            })
            .then(function (datos) {
                datos.forEach(usuario => {

                    console.log(usuario);


                });


            })


    })

    //Apartado C


    boton.addEventListener("click", function () {

        fetch(url)
            .then(function (respuesta) {
                if (!respuesta.ok) {
                    throw new Error("Error al cargar el usuario: " + respuesta.status);
                }
                return respuesta.json();
            })
            .then(function (datos) {

                for (const usuario of datos) {

                    for (const key in usuario) {

                        console.log(key + ": "+ usuario[key]);
                        
                        
                    


                    }

                }


            })


    })


}